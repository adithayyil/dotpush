// Just check if we're on a LeetCode problem page
if (window.location.href.startsWith("https://leetcode.com/problems/")) {
  // You're on a LeetCode problem page
} else {
  // Not a LeetCode problem page
}
